# dashboard.py
import streamlit as st
import pandas as pd
import plotly.express as px

# --------- Configuração da Página ---------
st.set_page_config(page_title="Dashboard de Análise & Chatbot", layout="wide")
st.title("Dashboard de Análise & Chatbot")


# --------- Carregar Dataset com Cache ---------
@st.cache_data
def load_data(path):
    df = pd.read_csv(path)
    # Remover colunas desnecessárias como Unnamed: 0
    df = df.loc[:, ~df.columns.str.contains('^Unnamed')]
    return df

dataset_path = "fortaleza_processado.csv" 
df = load_data(dataset_path)

# --------- Visualização do Dataset ---------
st.header("Exploração de Dados")
if st.checkbox("Mostrar Dataset"):
    st.dataframe(df)

# --------- Estatísticas Descritivas ---------
if st.checkbox("Estatísticas Descritivas"):
    st.write(df.describe())

# --------- Gráficos Interativos ---------
st.header("Gráficos Interativos")

# ----------------- Gráfico de Barras -----------------
col_barras = st.selectbox("Escolha a coluna para gráfico de barras:", df.columns)

if pd.api.types.is_numeric_dtype(df[col_barras]):
    counts = df[col_barras].value_counts(bins=20).sort_index()
    fig_bar = px.bar(
        x=[f"{interval.left:.1f} - {interval.right:.1f}" for interval in counts.index],
        y=counts.values,
        labels={'x': col_barras, 'y':'Contagem'},
        text=counts.values
    )
else:
    counts = df[col_barras].value_counts()
    fig_bar = px.bar(
        x=counts.index,
        y=counts.values,
        labels={'x': col_barras, 'y':'Contagem'},
        text=counts.values
    )
st.plotly_chart(fig_bar, use_container_width=True)

# ----------------- Gráfico de Linha -----------------
col_linha = st.selectbox("Escolha a coluna para gráfico de linha:", df.select_dtypes(include='number').columns)
fig_line = px.line(df, y=col_linha, labels={'y': col_linha})
st.plotly_chart(fig_line, use_container_width=True)

# ----------------- Histograma -----------------
col_hist = st.selectbox("Escolha a coluna para histograma:", df.select_dtypes(include='number').columns)
fig_hist = px.histogram(df, x=col_hist, nbins=20, labels={'x': col_hist})
st.plotly_chart(fig_hist, use_container_width=True)

